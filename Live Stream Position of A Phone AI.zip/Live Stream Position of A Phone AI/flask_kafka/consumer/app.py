from distutils.log import debug
from kafka import KafkaConsumer
from kafka import KafkaProducer
from json import loads
from time import sleep
import pandas as pd
import json
import time
import pickle
from threading import Lock
from flask import Flask, render_template, session
from flask_socketio import SocketIO, emit
import requests
async_mode = None

app = Flask(__name__)
socketio = SocketIO(app, async_mode=async_mode)
thread = None
thread_lock = Lock()



clf_knn1=pickle.load(open("../../trained_models/knn_model.pkl","rb") )
clf_dt1=pickle.load(open("../../trained_models/decision_tree_model.pkl","rb") )
clf_rf1=pickle.load(open("../../trained_models/random_forest_model.pkl","rb") )
clf_be1=pickle.load(open("../../trained_models/bagging_ensemble_model.pkl","rb") )

consumer = KafkaConsumer('bigdata', bootstrap_servers=['localhost:9092'], api_version=(0, 10))


#function to return label value when sent a label
def get_label(label):
    if label == [1]:
        return "NotWithMe"
    elif label == [2]:
        return "PhoneInUse"
    elif label == [3]:
        return "Standing"
    elif label == [4]:
        return "Walking"
    elif label == [5]:
        return "Running"
    else:
        return "Unknown"

def get_state(message):

    #changing the message in bytes to string to values of the sensors
    m = message.value.decode('utf-8')
    m = m.split(',')
    m[0] = m[0].replace('[', '')
    m[-1] = m[-1].replace(']', '')
    m = [float(i) for i in m[:-1]]
    if(len(m)==5):
        m.append(0.0)

    #creating a dataframe with the values of the sensors (to remove warning)
    df = pd.DataFrame()
    gyroscope=pd.DataFrame()
    accelerometer=pd.DataFrame()
    df['gposx'] = [m[0]]
    df['gposy'] = [m[1]]
    df['gposz'] = [m[2]]
    df['aposx'] = [m[3]]
    df['aposy'] = [m[4]]
    df['aposz'] = [m[5]]

    gyroscope['gposx'] = [m[0]]
    gyroscope['gposy'] = [m[1]]
    gyroscope['gposz'] = [m[2]]
    accelerometer['aposx'] = [m[3]]
    accelerometer['aposy'] = [m[4]]
    accelerometer['aposz'] = [m[5]]
   
   

    # df.columns = [['gposx', 'gposy', 'gposz', 'aposx', 'aposy', 'aposz']]

    #predicting labels
    knn = get_label(clf_knn1.predict(df))
    dt = get_label(clf_dt1.predict(df))
    rf = get_label(clf_rf1.predict(df))
    be = get_label(clf_be1.predict(df))
    print("*****************************");
    print("Knn predicts: ", knn)
    print("Decision Tree predicts: ", dt)
    print("Random Forest predicts: ", rf)
    print("Bagging Ensemble predicts: ", be)
    print("*****************************");
    return knn, dt, rf, be, m[0],m[1],m[2],m[3],m[4],m[5]



#runs ok but inorder to update the values you would have to refresh the page again and again
# @app.route("/",methods=["GET"])
# def index():
#     k=0
#     for message in consumer:
#         print("message received")
#         print(message.value.decode('utf-8'))
#         knn, dt,rf,be = get_state(message)
#         preds = [knn, dt,rf,be]
#         # time.sleep(1)
#         # count+=1
#         # render_template('index1.html', preds=preds)
#         return message.value.decode('utf-8')


# if __name__ == '__main__':
#     app.debug = True
#     app.run(host="0.0.0.0")





def background_thread():
    count = 0
    # gyroscope=pd.DataFrame()
    # accelerometer=pd.DataFrame()
    for message in consumer:
        # socketio.sleep(1)
        count += 1
        # price = ((requests.get(url)).json())['data']['amount']
        #  {'data': 'Bitcoin current price (USD): ' + price, 'count': count}
        knn, dt,rf,be,m0,m1,m2,m3,m4,m5= get_state(message)
        socketio.emit('my_response',{'knn': knn, 'dt': dt, 'rf':rf, 'be':be ,'m0':m0, 'm1':m1,'m2':m2,'m3':m3,'m4':m4,'m5':m5})

@app.route('/')
def index():
    return render_template('index.html', async_mode=socketio.async_mode)
# @socketio.event
# def my_event(message):
#     session['receive_count'] = session.get('receive_count', 0) + 1
#     emit('my_response',
#         #  {'data': message['data'], 'count': session['receive_count']})
#         {'knn': message['knn'], 'dt': message['dt'],'rf': message['rf'],'be': message['be'],'count': session['receive_count']})


@socketio.event
def connect():
    global thread
    with thread_lock:
        if thread is None:
            thread = socketio.start_background_task(background_thread)
    emit('my_response', {'data': 'Connected', 'count': 0})

if __name__ == '__main__':
    socketio.run(app,port=5002,debug=True)