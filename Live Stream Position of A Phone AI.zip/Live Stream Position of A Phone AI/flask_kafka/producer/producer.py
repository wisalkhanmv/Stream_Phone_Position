#create venv with the command: py -3 -m venv .venv
#activate venv with the command: source .venv/bin/activate
#install kafka with the command: pip install kafka-python
#install pandas,json, and flask with the command: pip install pandas json flask
#run the producer with the command: 

from kafka import KafkaConsumer
from kafka import KafkaProducer
from datetime import datetime
import pandas as pd
# import app
from json import loads
from time import sleep
import json
import time
import consumer_func as cons
from flask import Flask, jsonify, request, render_template,session
# from threading import Lock
# from flask_socketio import SocketIO, emit
# import requests


response = [0.0]*6

consumer = KafkaConsumer('bigdata', bootstrap_servers=['localhost:9092'], api_version=(0, 10))


app = Flask(__name__)
@app.route('/', methods=['POST'])
def sensorRoute():
    global response
 
    request_data = request.data
    request_data = json.loads(request_data.decode( "utf-8"))
    # print(request_data)
    temp = [request_data['gposx'],request_data['gposy'],request_data['gposz'],request_data['aposx'],request_data['aposy'],request_data['aposz']]
    temp = str(temp)
    print("data sending")
    producer = KafkaProducer(bootstrap_servers=['localhost:9092'], api_version=(0, 10, 1))
    producer.send('bigdata', bytes(temp,'utf-8'))
    # time.sleep(1)
    print("data sent")

    return ""



# @app.route("/",methods=["GET"])
# def index():
#     k=0
#     for message in consumer:
#         print("message received")
#         knn, dt,rf,be = cons.get_state(message)
#         preds = [knn, dt,rf,be]
#         time.sleep(1)
#         # count+=1
#         # render_template('index1.html', preds=preds)
#         return render_template('index1.html', preds=preds)



   
# @app.route("/")
# def home():
#     return "Hello, Flask!"

if __name__ == '__main__':
    app.debug = True
    app.run(host="0.0.0.0",port=5001)